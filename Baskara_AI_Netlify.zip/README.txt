BASKARA AI — VERSI NETLIFY (DEPLOY DARI HP)

1. Ekstrak ZIP.
2. Unggah file dan folder ke repository GitHub. Pastikan index.html, netlify.toml, package.json, dan folder netlify/functions/chat.js serta image.js ada di root repository.
3. Di Netlify, buka site yang terhubung ke repository itu.
4. Buka Site configuration (atau Project configuration) → Environment variables.
5. Tambahkan OPENAI_API_KEY dengan nilai API key dari dashboard OpenAI Platform. Jangan taruh API key di index.html/GitHub.
6. Simpan, lalu lakukan redeploy / Deploy latest commit.
7. Buka URL Netlify dan uji chat. Pencarian web dan pembuatan gambar membutuhkan akses API/model serta billing API aktif.

Fitur:
- Chat menggunakan OpenAI Responses API (model default gpt-4.1-mini)
- Pencarian web melalui tool web_search
- Pembuatan gambar melalui images/generations (gpt-image-1)
- Input suara dan text-to-speech memakai kemampuan browser; dukungan tergantung browser/perizinan.

PENTING:
- Paket ini sudah disesuaikan untuk Netlify Functions, tidak memakai server.js lokal.
- ChatGPT Free/Plus tidak otomatis mencakup saldo API. API bisa berbayar.
- Jangan bagikan API key atau commit ke GitHub.
- Kalau Netlify sebelumnya mengarah ke repository lama, unggah/ganti file di repository yang benar.
