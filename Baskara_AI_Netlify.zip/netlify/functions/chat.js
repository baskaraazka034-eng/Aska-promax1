exports.handler = async (event) => {
  const headers = {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers, body: "" };
  if (event.httpMethod !== "POST") return { statusCode: 405, headers, body: JSON.stringify({ error: "Gunakan POST." }) };
  const key = process.env.OPENAI_API_KEY;
  if (!key) return { statusCode: 500, headers, body: JSON.stringify({ error: "OPENAI_API_KEY belum diatur di Netlify Site configuration → Environment variables." }) };
  try {
    const body = JSON.parse(event.body || "{}");
    const messages = Array.isArray(body.messages) ? body.messages.slice(-20) : [];
    const input = messages.map(m => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content || "").slice(0, 12000)
    }));
    if (!input.length) return { statusCode: 400, headers, body: JSON.stringify({ error: "Tulis pesan terlebih dahulu." }) };
    const payload = {
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      instructions: "Kamu adalah Baskara AI, asisten yang ramah, membantu, dan jelas. Jawab dalam bahasa pengguna, utamakan bahasa Indonesia bila cocok. Jangan mengaku sebagai manusia. Jika tidak tahu, katakan dengan jujur.",
      input
    };
    if (body.webSearch) payload.tools = [{ type: "web_search" }];
    const r = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await r.json();
    if (!r.ok) throw new Error(data?.error?.message || `OpenAI API error (${r.status})`);
    const answer = data.output_text || (data.output || []).flatMap(x => x.content || []).map(x => x.text || "").join("\n") || "Maaf, belum ada jawaban.";
    return { statusCode: 200, headers, body: JSON.stringify({ answer }) };
  } catch (e) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: e.message || "Terjadi kesalahan." }) };
  }
};
