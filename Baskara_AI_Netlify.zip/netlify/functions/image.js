exports.handler = async (event) => {
  const headers = {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers, body: "" };
  if (event.httpMethod !== "POST") return { statusCode: 405, headers, body: JSON.stringify({ error: "Gunakan POST." }) };
  const key = process.env.OPENAI_API_KEY;
  if (!key) return { statusCode: 500, headers, body: JSON.stringify({ error: "OPENAI_API_KEY belum diatur di Netlify Environment variables." }) };
  try {
    const body = JSON.parse(event.body || "{}");
    const prompt = String(body.prompt || "").trim().slice(0, 3000);
    if (!prompt) return { statusCode: 400, headers, body: JSON.stringify({ error: "Tulis deskripsi gambar terlebih dahulu." }) };
    const r = await fetch("https://api.openai.com/v1/images/generations", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model: "gpt-image-1", prompt: prompt + "\nCreate a high-quality image.", size: "1024x1024" })
    });
    const data = await r.json();
    if (!r.ok) throw new Error(data?.error?.message || `OpenAI API error (${r.status})`);
    const item = data.data && data.data[0];
    if (item?.b64_json) return { statusCode: 200, headers, body: JSON.stringify({ image: "data:image/png;base64," + item.b64_json }) };
    if (item?.url) return { statusCode: 200, headers, body: JSON.stringify({ image: item.url }) };
    throw new Error("API tidak mengembalikan gambar.");
  } catch (e) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: e.message || "Gagal membuat gambar." }) };
  }
};
